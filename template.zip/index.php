<?php
include 'config.php';
$_SERVER['REQUEST_URI'] = str_replace('/'.EV_SUBFOLDER, '', $_SERVER['REQUEST_URI']);

$page = substr(explode('?', $_SERVER['REQUEST_URI'])[0], 1, 128); 
$page .= (empty($page) ? 'index' : $page);

$file = 'templates/'.$page.'.php';
if(!file_exists($file)){
    header("Location: ".EV_404); die();
}

include 'templates/main.php';
?>