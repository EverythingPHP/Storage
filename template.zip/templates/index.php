<div class="d-flex w-100">
    <div class="ms-auto me-auto mt-3 p-3 d-flex flex-column">
        <div style="text-align: center;">
            <h2>Tired of hard-to-learn PHP frameworks like Laravel?</h2>
            <h4>Try Everything.</h4>
        </div>
        
        <div class="d-flex flex-row flex-wrap gap-3 w-50 ms-auto me-auto justify-content-center mt-3" style="width: 70vw!important;">
            
            <div class="card" style="width: 30vw;">
                <div class="card-body">
                    <h5 class="card-title">Efficiency</h5>
                    <p class="card-text">By using Everything you can save a lot of time, by simply having a ready-to-use package manager, templates, and what's the best - an ability to write PHP code directly, bypassing controllers and other OOP stuff that you're probably sick about.</p>
                </div>
            </div>
            <div class="card" style="width: 30vw;">
                <div class="card-body">
                    <h5 class="card-title">Flexibility</h5>
                    <p class="card-text">Everything is more of an add-on to your website, rather than a framework. Because in the most cases, you can simply remove it from the website flawlessly.</p>
                </div>
            </div>

            <div class="card" style="width: 30vw;">
                <div class="card-body">
                    <h5 class="card-title">Understanding</h5>
                    <p class="card-text">Don't understand popular frameworks, and used to writing websites all by yourself? Well, continue doing that, and just speed up your work, and while you're doing that, you still can keep an eye on Everything's source code, which is written by a human - to a human.</p>
                </div>
            </div>
            <div class="card" style="width: 30vw;">
                <div class="card-body">
                    <h5 class="card-title">Basics</h5>
                    <p class="card-text">Some basics are also explained in Everything's wiki. If you're having trouble - keep looking, and you'll find an answer.</p>
                </div>
            </div>
        </div>
    </div>
</div>