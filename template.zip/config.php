<?php

define('EV_SUBFOLDER', 'pay2me');
define('EV_404', './');
define('EV_TITLE', 'Everything');